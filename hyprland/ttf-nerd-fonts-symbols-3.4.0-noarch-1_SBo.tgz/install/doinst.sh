if [ -x /usr/bin/fc-cache ]; then
  /usr/bin/fc-cache -f
fi
( cd etc/fonts/conf.d ; rm -rf 10-nerd-font-symbols.conf )
( cd etc/fonts/conf.d ; ln -sf ../conf.avail/10-nerd-font-symbols.conf 10-nerd-font-symbols.conf )
