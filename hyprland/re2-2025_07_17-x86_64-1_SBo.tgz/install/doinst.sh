( cd usr/lib64 ; rm -rf libre2.so )
( cd usr/lib64 ; ln -sf libre2.so.11.0.0 libre2.so )
( cd usr/lib64 ; rm -rf libre2.so.11 )
( cd usr/lib64 ; ln -sf libre2.so.11.0.0 libre2.so.11 )
