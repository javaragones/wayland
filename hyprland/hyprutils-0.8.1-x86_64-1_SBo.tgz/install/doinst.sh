if [ -x /usr/bin/update-desktop-database ]; then
  /usr/bin/update-desktop-database -q usr/share/applications >/dev/null 2>&1
fi

if [ -e usr/share/icons/hicolor/icon-theme.cache ]; then
  if [ -x /usr/bin/gtk-update-icon-cache ]; then
    /usr/bin/gtk-update-icon-cache -f usr/share/icons/hicolor >/dev/null 2>&1
  fi
fi
( cd usr/lib64 ; rm -rf libhyprutils.so )
( cd usr/lib64 ; ln -sf libhyprutils.so.7 libhyprutils.so )
( cd usr/lib64 ; rm -rf libhyprutils.so.7 )
( cd usr/lib64 ; ln -sf libhyprutils.so.0.8.1 libhyprutils.so.7 )
