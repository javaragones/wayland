if [ -x /usr/bin/update-desktop-database ]; then
  /usr/bin/update-desktop-database -q usr/share/applications >/dev/null 2>&1
fi

if [ -e usr/share/icons/hicolor/icon-theme.cache ]; then
  if [ -x /usr/bin/gtk-update-icon-cache ]; then
    /usr/bin/gtk-update-icon-cache -f usr/share/icons/hicolor >/dev/null 2>&1
  fi
fi
( cd usr/lib64 ; rm -rf libhyprcursor.so )
( cd usr/lib64 ; ln -sf libhyprcursor.so.0 libhyprcursor.so )
( cd usr/lib64 ; rm -rf libhyprcursor.so.0 )
( cd usr/lib64 ; ln -sf libhyprcursor.so.0.1.13 libhyprcursor.so.0 )
