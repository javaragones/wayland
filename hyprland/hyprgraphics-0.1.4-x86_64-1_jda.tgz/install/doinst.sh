( cd usr/lib64 ; rm -rf libhyprgraphics.so )
( cd usr/lib64 ; ln -sf libhyprgraphics.so.0 libhyprgraphics.so )
( cd usr/lib64 ; rm -rf libhyprgraphics.so.0 )
( cd usr/lib64 ; ln -sf libhyprgraphics.so.0.1.4 libhyprgraphics.so.0 )
