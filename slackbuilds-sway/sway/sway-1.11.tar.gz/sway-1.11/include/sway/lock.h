#ifndef _SWAY_LOCK_H
#define _SWAY_LOCK_H

void arrange_locks(void);

#endif
