#ifndef _SWAYBAR_IMAGE_H
#define _SWAYBAR_IMAGE_H
#include <cairo.h>

cairo_surface_t *load_image(const char *path);

#endif
