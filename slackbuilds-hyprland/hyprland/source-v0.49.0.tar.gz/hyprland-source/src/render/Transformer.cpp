#include "Transformer.hpp"

void IWindowTransformer::preWindowRender(CSurfacePassElement::SRenderData* pRenderData) {
    ;
}