#include "IHID.hpp"

eHIDType IHID::getType() {
    return HID_TYPE_UNKNOWN;
}
