#pragma once

#include <hyprutils/string/VarList.hpp>

//NOLINTNEXTLINE
using namespace Hyprutils::String;
