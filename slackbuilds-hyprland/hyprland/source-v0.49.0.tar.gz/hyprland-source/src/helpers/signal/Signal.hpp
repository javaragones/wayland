#pragma once

#include <hyprutils/signal/Signal.hpp>

//NOLINTNEXTLINE
using namespace Hyprutils::Signal;
