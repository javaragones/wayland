#pragma once

#include <string>

namespace NHyprlandSocket {
    std::string send(const std::string& cmd);
};