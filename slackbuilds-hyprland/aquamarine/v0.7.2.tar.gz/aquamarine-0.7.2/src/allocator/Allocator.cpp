#include <aquamarine/allocator/Allocator.hpp>

void Aquamarine::IAllocator::destroyBuffers() {}
