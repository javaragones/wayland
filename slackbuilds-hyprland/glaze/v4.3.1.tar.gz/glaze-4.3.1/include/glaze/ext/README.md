# Glaze Extensions

These extension headers are to be used with other libraries. Glaze expects developers to include the other libraries however they desire and then include the additional Glaze headers from this `ext` directory.

> [!NOTE]
>
> `cli_menu.hpp` has no external dependencies and should be moved out

