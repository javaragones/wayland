#pragma once

#define CLIPBOARDMESSAGESIZE 24

namespace Clipboard {
    void copy(const char* fmt, ...);
};