#pragma once

#include <stdbool.h>

bool tokenize_cmdline(const char *cmdline, char ***argv);
