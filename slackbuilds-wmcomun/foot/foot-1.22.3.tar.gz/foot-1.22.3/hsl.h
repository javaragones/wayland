#pragma once

#include <stdint.h>

uint32_t hsl_to_rgb(int hue, int sat, int lum);
