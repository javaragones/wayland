#include <3rd-party/nanosvg/src/nanosvgrast.h>
