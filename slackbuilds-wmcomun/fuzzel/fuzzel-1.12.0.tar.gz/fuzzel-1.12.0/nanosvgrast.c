#include <stdlib.h>
#include <string.h>

#include <3rd-party/nanosvg/src/nanosvg.h>
#define NANOSVGRAST_IMPLEMENTATION
#include <3rd-party/nanosvg/src/nanosvgrast.h>
