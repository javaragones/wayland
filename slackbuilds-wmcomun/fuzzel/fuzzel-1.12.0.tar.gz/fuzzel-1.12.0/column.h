#pragma once

#include <uchar.h>
char32_t *nth_column(const char32_t *column, unsigned int nth);
